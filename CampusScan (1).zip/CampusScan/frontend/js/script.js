// ============================================
// CampusScan - Shared Frontend Logic
// ============================================
const API_BASE = '/api';

// ---------- Session helpers ----------
function saveSession(token, user, role) {
  localStorage.setItem('cs_token', token);
  localStorage.setItem('cs_user', JSON.stringify(user));
  localStorage.setItem('cs_role', role);
}
function getToken() { return localStorage.getItem('cs_token'); }
function getUser() {
  const raw = localStorage.getItem('cs_user');
  return raw ? JSON.parse(raw) : null;
}
function getRole() { return localStorage.getItem('cs_role'); }
function logout() {
  localStorage.removeItem('cs_token');
  localStorage.removeItem('cs_user');
  localStorage.removeItem('cs_role');
  window.location.href = 'index.html';
}

// Redirect to the right login page if not authenticated as `role`
function guardPage(requiredRole) {
  const token = getToken();
  const role = getRole();
  if (!token || role !== requiredRole) {
    window.location.href = requiredRole === 'staff' ? 'staff-login.html' : 'student-login.html';
  }
}

// Wrapper around fetch that attaches the JWT + JSON headers
async function apiFetch(path, options = {}) {
  const token = getToken();
  const headers = Object.assign(
    { 'Content-Type': 'application/json' },
    options.headers || {},
    token ? { Authorization: `Bearer ${token}` } : {}
  );
  const res = await fetch(API_BASE + path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
}

// ---------- Alert helper ----------
function showAlert(elId, message, type = 'error') {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = message;
  el.className = `alert show alert-${type}`;
}

// ---------- Status/priority badge helpers ----------
function statusBadgeClass(status) {
  return {
    'Pending': 'badge-pending',
    'In Progress': 'badge-progress',
    'Resolved': 'badge-resolved',
    'Rejected': 'badge-rejected'
  }[status] || 'badge-pending';
}
function priorityBadgeClass(priority) {
  return {
    'Low': 'badge-low',
    'Medium': 'badge-medium',
    'High': 'badge-high'
  }[priority] || 'badge-medium';
}
function formatDate(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

// ============================================
// PAGE: student-login.html
// ============================================
const studentLoginForm = document.getElementById('studentLoginForm');
if (studentLoginForm) {
  studentLoginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    try {
      const data = await apiFetch('/student/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      saveSession(data.token, data.user, 'student');
      window.location.href = 'student-dashboard.html';
    } catch (err) {
      showAlert('loginAlert', err.message, 'error');
    }
  });
}

// ============================================
// PAGE: student-login.html (Register tab)
// ============================================
const studentRegisterForm = document.getElementById('studentRegisterForm');
if (studentRegisterForm) {
  studentRegisterForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      reg_no: document.getElementById('reg_no').value.trim(),
      name: document.getElementById('name').value.trim(),
      email: document.getElementById('reg_email').value.trim(),
      password: document.getElementById('reg_password').value,
      department: document.getElementById('department').value,
      year: document.getElementById('year').value,
      phone: document.getElementById('phone').value.trim()
    };
    try {
      await apiFetch('/student/register', { method: 'POST', body: JSON.stringify(payload) });
      showAlert('registerAlert', 'Registration successful! Please login.', 'success');
      studentRegisterForm.reset();
      setTimeout(() => {
        document.getElementById('loginTabBtn')?.click();
      }, 1200);
    } catch (err) {
      showAlert('registerAlert', err.message, 'error');
    }
  });
}

// Tab toggle (login/register on student-login.html)
const loginTabBtn = document.getElementById('loginTabBtn');
const registerTabBtn = document.getElementById('registerTabBtn');
if (loginTabBtn && registerTabBtn) {
  loginTabBtn.addEventListener('click', () => {
    loginTabBtn.classList.add('active');
    registerTabBtn.classList.remove('active');
    document.getElementById('loginPane').style.display = 'block';
    document.getElementById('registerPane').style.display = 'none';
  });
  registerTabBtn.addEventListener('click', () => {
    registerTabBtn.classList.add('active');
    loginTabBtn.classList.remove('active');
    document.getElementById('registerPane').style.display = 'block';
    document.getElementById('loginPane').style.display = 'none';
  });
}

// ============================================
// PAGE: staff-login.html
// ============================================
const staffLoginForm = document.getElementById('staffLoginForm');
if (staffLoginForm) {
  staffLoginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    try {
      const data = await apiFetch('/staff/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      saveSession(data.token, data.user, 'staff');
      window.location.href = 'staff-dashboard.html';
    } catch (err) {
      showAlert('loginAlert', err.message, 'error');
    }
  });
}

// ============================================
// PAGE: student-dashboard.html
// ============================================
const studentDashRoot = document.getElementById('studentDashRoot');
if (studentDashRoot) {
  guardPage('student');
  const user = getUser();
  document.getElementById('welcomeName').textContent = user.name;
  document.getElementById('sidebarName').textContent = user.name;
  document.getElementById('sidebarDept').textContent = `${user.department} · ${user.reg_no || ''}`;

  (async () => {
    try {
      const data = await apiFetch('/complaint/my');
      const complaints = data.complaints || [];
      document.getElementById('totalCount').textContent = complaints.length;
      document.getElementById('pendingCount').textContent = complaints.filter(c => c.status === 'Pending').length;
      document.getElementById('progressCount').textContent = complaints.filter(c => c.status === 'In Progress').length;
      document.getElementById('resolvedCount').textContent = complaints.filter(c => c.status === 'Resolved').length;

      const tbody = document.getElementById('recentComplaintsBody');
      const emptyState = document.getElementById('emptyState');
      if (complaints.length === 0) {
        emptyState.style.display = 'block';
      } else {
        emptyState.style.display = 'none';
        tbody.innerHTML = complaints.slice(0, 5).map(c => `
          <tr>
            <td>#${c.id}</td>
            <td>${c.title}</td>
            <td>${c.category}</td>
            <td><span class="badge ${statusBadgeClass(c.status)}">${c.status}</span></td>
            <td>${formatDate(c.created_at)}</td>
          </tr>
        `).join('');
      }
    } catch (err) {
      console.error(err);
    }
  })();
}

// ============================================
// PAGE: complaint.html (submit new complaint)
// ============================================
const complaintForm = document.getElementById('complaintForm');
if (complaintForm) {
  guardPage('student');
  complaintForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      title: document.getElementById('title').value.trim(),
      description: document.getElementById('description').value.trim(),
      category: document.getElementById('category').value,
      location: document.getElementById('location').value.trim(),
      priority: document.getElementById('priority').value,
      is_anonymous: document.getElementById('is_anonymous').checked
    };
    try {
      await apiFetch('/complaint/add', { method: 'POST', body: JSON.stringify(payload) });
      showAlert('complaintAlert', 'Complaint submitted successfully!', 'success');
      complaintForm.reset();
      setTimeout(() => { window.location.href = 'status.html'; }, 1000);
    } catch (err) {
      showAlert('complaintAlert', err.message, 'error');
    }
  });
}

// ============================================
// PAGE: status.html (student's own complaints)
// ============================================
const statusListEl = document.getElementById('statusList');
if (statusListEl) {
  guardPage('student');

  async function loadMyComplaints() {
    try {
      const data = await apiFetch('/complaint/my');
      let complaints = data.complaints || [];

      const filterVal = document.getElementById('statusFilter')?.value;
      if (filterVal && filterVal !== 'all') {
        complaints = complaints.filter(c => c.status === filterVal);
      }

      if (complaints.length === 0) {
        statusListEl.innerHTML = `
          <div class="empty-state">
            <div class="icon">📭</div>
            <p>No complaints found.</p>
          </div>`;
        return;
      }

      statusListEl.innerHTML = complaints.map(c => `
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:start;gap:12px;flex-wrap:wrap;">
            <div>
              <h3 style="margin-bottom:6px;">#${c.id} · ${c.title}</h3>
              <p style="color:var(--text-muted);font-size:13.5px;">${c.category} ${c.location ? '· ' + c.location : ''} · Filed ${formatDate(c.created_at)}</p>
            </div>
            <div style="display:flex;gap:8px;">
              <span class="badge ${statusBadgeClass(c.status)}">${c.status}</span>
              <span class="badge ${priorityBadgeClass(c.priority)}">${c.priority}</span>
            </div>
          </div>
          <p style="margin-top:12px;font-size:14px;">${c.description}</p>
          ${c.staff_response ? `<div style="margin-top:14px;padding:12px;background:var(--bg);border-radius:8px;">
            <strong style="font-size:13px;">Staff Response:</strong>
            <p style="font-size:13.5px;margin-top:4px;">${c.staff_response}</p>
          </div>` : ''}
        </div>
      `).join('');
    } catch (err) {
      console.error(err);
    }
  }

  document.getElementById('statusFilter')?.addEventListener('change', loadMyComplaints);
  loadMyComplaints();
}

// ============================================
// PAGE: staff-dashboard.html
// ============================================
const staffDashRoot = document.getElementById('staffDashRoot');
if (staffDashRoot) {
  guardPage('staff');
  const user = getUser();
  document.getElementById('sidebarName').textContent = user.name;
  document.getElementById('sidebarDept').textContent = `${user.designation || 'Staff'} · ${user.department}`;

  async function loadStats() {
    try {
      const data = await apiFetch('/staff/stats');
      const s = data.stats;
      document.getElementById('totalCount').textContent = s.total;
      document.getElementById('pendingCount').textContent = s.pending;
      document.getElementById('progressCount').textContent = s.inProgress;
      document.getElementById('resolvedCount').textContent = s.resolved;
    } catch (err) { console.error(err); }
  }

  async function loadComplaints() {
    const status = document.getElementById('statusFilter')?.value;
    const category = document.getElementById('categoryFilter')?.value;
    let query = [];
    if (status && status !== 'all') query.push(`status=${encodeURIComponent(status)}`);
    if (category && category !== 'all') query.push(`category=${encodeURIComponent(category)}`);
    const qs = query.length ? `?${query.join('&')}` : '';

    try {
      const data = await apiFetch(`/complaint/all${qs}`);
      const complaints = data.complaints || [];
      const tbody = document.getElementById('complaintsBody');
      const emptyState = document.getElementById('emptyState');

      if (complaints.length === 0) {
        tbody.innerHTML = '';
        emptyState.style.display = 'block';
        return;
      }
      emptyState.style.display = 'none';

      tbody.innerHTML = complaints.map(c => `
        <tr>
          <td>#${c.id}</td>
          <td>${c.title}</td>
          <td>${c.student_name}${c.reg_no ? ' (' + c.reg_no + ')' : ''}</td>
          <td>${c.category}</td>
          <td><span class="badge ${priorityBadgeClass(c.priority)}">${c.priority}</span></td>
          <td><span class="badge ${statusBadgeClass(c.status)}">${c.status}</span></td>
          <td>${formatDate(c.created_at)}</td>
          <td><button class="btn btn-outline" style="padding:6px 14px;font-size:12.5px;" onclick="openUpdateModal(${c.id}, '${c.status}')">Manage</button></td>
        </tr>
      `).join('');
    } catch (err) { console.error(err); }
  }

  document.getElementById('statusFilter')?.addEventListener('change', loadComplaints);
  document.getElementById('categoryFilter')?.addEventListener('change', loadComplaints);

  loadStats();
  loadComplaints();

  // Modal logic for updating complaint status
  window.openUpdateModal = function (id, currentStatus) {
    document.getElementById('modalComplaintId').value = id;
    document.getElementById('modalStatus').value = currentStatus;
    document.getElementById('modalResponse').value = '';
    document.getElementById('updateModal').classList.add('show');
  };
  window.closeUpdateModal = function () {
    document.getElementById('updateModal').classList.remove('show');
  };

  document.getElementById('updateForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('modalComplaintId').value;
    const status = document.getElementById('modalStatus').value;
    const staff_response = document.getElementById('modalResponse').value.trim();
    try {
      await apiFetch(`/complaint/update/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ status, staff_response })
      });
      window.closeUpdateModal();
      loadStats();
      loadComplaints();
    } catch (err) {
      alert(err.message);
    }
  });
}

// ============================================
// Logout buttons (all dashboard pages)
// ============================================
document.querySelectorAll('.logout-btn').forEach(btn => {
  btn.addEventListener('click', logout);
});
